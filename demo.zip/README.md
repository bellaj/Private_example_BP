# Demo

Install python 3

Install Metamask extension 

Get ropsten testnet ethers from : https://ipfs.io/ipfs/QmVAwVKys271P5EQyEfVSxm7BJDKWt42A2gHvNmxLjZMps/
or from https://faucet.egorfine.com/

Run the project using in a cmd:

`python -m http.server 8080`
